package com.company;
import java.io.*;
import java.util.HashMap;
import java.util.StringTokenizer;



public class Main {

    public static void main(String[] args) throws IOException {


        HashMap<Integer , Student> hm = new HashMap<Integer, Student>();
        readInput("/Users/samiyounis/IdeaProjects/Assignment/Students",hm);
        printAllMarks(hm);



    }



     //////////////////For Print Marks//////////////////////

    static void printAllMarks(HashMap<Integer,Student> hm) throws FileNotFoundException
    {
        File oFile = new File("/Users/samiyounis/IdeaProjects/Assignment/src/output");
        PrintStream output = new PrintStream(oFile);
        System.setOut(output);
        double All_Students_Marks = 0;
        double counter = 0;
        for (Object id:hm.keySet()
             ) {

            hm.get(id).getAllMarks();
            All_Students_Marks += hm.get(id).total_Marks;
            counter++;

        }
        double Student_Avg_Marks = All_Students_Marks/counter;
        System.out.println("\n");
        System.out.println("/////////////////////////////////////////////////");
        System.out.println("The Students Average equal = "+Student_Avg_Marks);
        System.out.println("/////////////////////////////////////////////////");

    }
    /////////////////////////////////////////////////////////



    ///////////////////////// For Read Inputs //////////////////////
    static void readInput(String filePath ,HashMap<Integer,Student> hm ) throws IOException {
        File studentsPath = new File(filePath);
        File filesList[] = studentsPath.listFiles();

        BufferedReader br;
        StringTokenizer st ;

        for (File file : filesList) {

            st = new StringTokenizer(file.getName());

            String name = st.nextToken();
            int id = Integer.parseInt(st.nextToken());

            br = new BufferedReader(new FileReader(file));
            st = new StringTokenizer(br.readLine(), ",");


            int num1, num2, num3, num4;
            num1 = Integer.parseInt(st.nextToken());
            num2 = Integer.parseInt(st.nextToken());
            num3 = Integer.parseInt(st.nextToken());
            num4 = Integer.parseInt(st.nextToken());


            hm.put(id, new Student(name, num1, num2, num3, num4));


        }
    }
    //////////////////////////////////////////////////




}
