package com.company;

public class Student {

    public String name;
    public int first_Exam_Mark;
    public int second_Exam_Mark;
    public int third_Exam_Mark;
    public int final_Exam_Mark;
    public int total_Marks;


    Student(String name ,int num1, int num2, int num3, int num4)
    {
        this.name = name;
        this.first_Exam_Mark = num1;
        this.second_Exam_Mark = num2;
        this.third_Exam_Mark = num3;
        this.final_Exam_Mark = num4;
        total_Marks = num1+num2+num3+num4;


    }
    public void getAllMarks ()
    {
        System.out.println(
                name+" : "
                +first_Exam_Mark+", "
                +second_Exam_Mark+", "
                +third_Exam_Mark+", "
                +final_Exam_Mark+" ---> Total Marks = "
                +total_Marks+"\n"
        );
    }






}
